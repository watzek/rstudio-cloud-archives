# intro-to-r-2020
Introduction to R, for Professor Weissman-Unni's Numbers courses
Link to this page: https://bit.ly/weissman-part1




### For use with rstudio.cloud 

* Visit https://rstudio.cloud, and sign in with your google account  
* Click the arrow next to "New Project", and select "from Github Repository"
* Enter the url: https://github.com/jeremymcwilliams/Core121-Weissman-2021-part1/
* Once the project loads, run `install.packages("tidyverse")` in the console.





#### To get started, click "intro-tutorial.Rmd" in the files window, and then minimize the console window. Then follow along with the instructions in the .Rmd document.




